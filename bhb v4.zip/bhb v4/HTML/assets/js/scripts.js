/* ============================================================

 Theme Name: BEGANA
 Theme URI: http://
 Description: The BEGANA Onepage Template
 Author: Landing Page
 Author URI:
 Version: 1.0

============================================================== */

$(function() {

    "use strict";// this function is executed in strict mode



	/* ------------------------------------------------------ */
	/*  1. SHRINK HEADER JS
	/* ------------------------------------------------------ */
	var shrinkHeader=1;
		$(window).on('scroll', function () {
		var scroll=getCurrentScroll();
			if(scroll>=shrinkHeader){
				$('.navbar').addClass('shrink');
			}
		else{
			$('.navbar').removeClass('shrink');}
	});
	function getCurrentScroll(){
		return window.pageYOffset;
	}

	var sections = $('section')
	  , nav = $('nav')
	  , nav_height = nav.outerHeight();

	/**  2. MENU active  JS **/
	$(window).on('scroll', function () {
		var cur_pos = $(this).scrollTop();
		sections.each(function() {
			var top = $(this).offset().top - nav_height,
				bottom = top + $(this).outerHeight();
			if (cur_pos >= top && cur_pos <= bottom) {
				nav.find('a').removeClass('active');
				sections.removeClass('active');

				$(this).addClass('active');
				nav.find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
			}
		});
	});

	/* --------------------------- */
	/*  2. MENU SMOOTH SCROLLING JS
	/* --------------------------- */
	$(function() {
        $('a[href*="#"]:not([data-toggle="tab"])').on('click', function() {
             if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                 var target = $(this.hash);
                 target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                 if (target.length) {
                     $('html, body').animate({
                         scrollTop: target.offset().top
                     }, 1000);
                     return false;
                 }
             }
        });
    });

	/* --------------------------- */
	/*  3. wow animate JS
	/* --------------------------- */
	new WOW().init();

	/* --------------------------- */
	/*  4. YouTube video click box JS
	/* --------------------------- */
	$('.video-v').magnificPopup({
	  type: 'iframe'
	  // other options
	});

	/* --------------------------- */
	/*  5. testimon slider JS
	/* --------------------------- */
	$('.testimon-slider').owlCarousel({
        items: 1,
        loop:true,
        margin: 0,
        autoplay:true,
        smartSpeed:600,
		dots: true,
		nav:false,
    });


});

$(document).ready(function() {

    var owl = $('.header .owl-carousel');
    // Slider owlCarousel
    $('.fullslider').owlCarousel({
        items: 1,
        loop:true,
        margin: 0,
        autoplay:true,
		dots: false,
        smartSpeed:600
    });

    owl.on('changed.owl.carousel', function(event) {
        var item = event.item.index - 2;
        $('h6').removeClass('animated fadeInLeft');
        $('h1').removeClass('animated fadeInRight');
        $('.butn').removeClass('animated zoomIn');
        $('.owl-item').not('.cloned').eq(item).find('h6').addClass('animated fadeInLeft');
        $('.owl-item').not('.cloned').eq(item).find('h1').addClass('animated fadeInRight');
        $('.owl-item').not('.cloned').eq(item).find('.butn').addClass('animated zoomIn');
    });

});
